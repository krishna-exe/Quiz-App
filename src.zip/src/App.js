import React, { Component } from "react";
import Nav from "./Routes/Nav";


import { useState } from "react";
import axios from "axios";
import Quiz from "./Components/Quiz";
import QuizOptions from "./Components/QuizOptions";

const App = () => {


    return (
        <Nav />
    );
}

export default App;

