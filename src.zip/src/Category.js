import { View, Image, Text, StyleSheet, TouchableOpacity} from 'react-native'
import React from 'react'
import CatTitle from './components/CatTitle'
import ModalDropdown from 'react-native-modal-dropdown'

const Category = (navigation) => {
  return (
    <View>
        <CatTitle/>
       {/* <TouchableOpacity onPress={()=>navigation.navigate("Quiz")} style={styles.button}>
        <Text style={styles.butText}>
            Start Quiz
        </Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={()=>navigation.navigate("")} style={styles.button}>
        <Text style={styles.butText}>
            Contact Us
        </Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={()=>navigation.navigate("Quiz")} style={styles.button}>
        <Text style={styles.butText}>
            Start Quiz
        </Text>
      </TouchableOpacity> */}
    <ModalDropdown options={['animal', 'fruit']}/>
        


    </View>
  )
}

export default Category


const styles = StyleSheet.create({
    image:{
        height:300,
        width:300,
        borderRadius:1000,
    },

    imageContainer:{
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom:80,
    },

    container:{
        flex: 1,
        paddingTop:10,
        paddingHorizontal:10,
        backgroundColor:'#14213D',
        
    },

   

    button:{
        borderColor:'black',
        borderWidth:2,
        borderRadius:16,
        width:'90%',
        backgroundColor:"#EB5E28",
        padding:16,
        alignItems:'center',
        alignSelf:'center',
        marginBottom:30,
    },
    butText:{
        fontSize:25,
        fontWeight:'bold',
        color:'white',
    },
});